@extends("admin.layouts.main")
@section("content")
    <p class="text-center">Đây là trang dành cho quản trị viên</p>
@endsection