<?php

use App\Http\Controllers\Admin\Ajax\TodoAjaxController;
use Illuminate\Support\Facades\Route;

// Route::group(["prefix" => "admin.ajax", "as" => "admin.ajax."], function () {
//     Route::apiResource("todos", TodoAjaxController::class)->except(["show"]);
// });
